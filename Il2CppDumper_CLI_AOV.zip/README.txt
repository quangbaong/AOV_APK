# Il2CppDumper CLI AOV (Windows x64)

Portable Il2CppDumper 6.7.46 with .NET runtime 6.0.36 included.
No system-wide .NET installation is needed.

Run:
    dump.cmd "C:\path\libil2cpp.so" "C:\path\global-metadata.dat" "C:\path\Dump"

Inputs must already be decoded. Use the AOV_APK repository capture script first.
Outputs: dump.cs, il2cpp.h, script.json, stringliteral.json, DummyDll.

Local modification: TryGetDefaultValue retains a MetadataOffset when decoding
throws, using the exporter's existing unsupported-value path. It does not invent
constants. Inspect MetadataOffset annotations before relying on default values.
The DLLs are inspection stubs, not recovered C# implementations.

patch-source contains the fallback patch source, its helper and Mono.Cecil.
The original input files are not modified. No game files or dump data are bundled.

Upstream: https://github.com/Perfare/Il2CppDumper/releases/tag/v6.7.46
Runtime: https://builds.dotnet.microsoft.com/dotnet/Runtime/6.0.36/dotnet-runtime-6.0.36-win-x64.zip
