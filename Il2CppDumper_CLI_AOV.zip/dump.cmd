@echo off
setlocal
if "%~1"=="" goto usage
if "%~2"=="" goto usage
set "OUTPUT=%~3"
if not defined OUTPUT set "OUTPUT=%~dp0Dump"
if not exist "%OUTPUT%" mkdir "%OUTPUT%"
"%~dp0runtime\dotnet.exe" "%~dp0tool\Il2CppDumper.dll" "%~f1" "%~f2" "%OUTPUT%"
exit /b %ERRORLEVEL%
:usage
echo Usage: dump.cmd "libil2cpp.so" "global-metadata.dat" [output-directory]
exit /b 2
